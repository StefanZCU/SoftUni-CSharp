﻿namespace Shapes.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
