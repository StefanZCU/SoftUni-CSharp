﻿namespace Shapes.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
