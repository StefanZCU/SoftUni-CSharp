﻿namespace Animals.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
