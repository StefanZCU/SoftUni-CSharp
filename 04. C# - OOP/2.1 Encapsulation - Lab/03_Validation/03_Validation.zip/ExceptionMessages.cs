﻿namespace PersonsInfo
{
    public class ExceptionMessages
    {
        public const string NameIsLessThanThreeSymbols = "{0} name cannot contain fewer than 3 symbols!";
        public const string AgeIsLessThanZero = "Age cannot be zero or a negative integer!";
        public const string SalaryIsLessThan650 = "Salary cannot be less than 650 leva!";
    }
}
