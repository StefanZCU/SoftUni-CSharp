﻿namespace P02.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
