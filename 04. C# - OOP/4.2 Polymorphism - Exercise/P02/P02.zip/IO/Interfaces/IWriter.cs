﻿namespace P02.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string str);
    }
}
