﻿namespace VehiclesExtension.Models.Interfaces
{
    public interface IBus : IVehicle
    {
        string DriveEmpty(double distance);
    }
}
