﻿namespace P02.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
