﻿namespace VehiclesExtension.Exceptions
{
    public class FuelIsNotPositiveNumber : Exception
    {
        public FuelIsNotPositiveNumber(string message) : base(message)
        {
        }
    }
}
