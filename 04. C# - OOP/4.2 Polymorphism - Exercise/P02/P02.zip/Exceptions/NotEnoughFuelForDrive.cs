﻿namespace VehiclesExtension.Exceptions
{
    public class NotEnoughFuelForDrive : Exception
    {
        public NotEnoughFuelForDrive(string message) : base(message)
        {
        }
    }
}
