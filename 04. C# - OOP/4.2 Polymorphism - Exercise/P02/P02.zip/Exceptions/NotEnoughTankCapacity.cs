﻿namespace VehiclesExtension.Exceptions
{
    public class NotEnoughTankCapacity : Exception
    {
        public NotEnoughTankCapacity(string message) : base(message)
        {
        }
    }
}
