﻿namespace WildFarm.Exceptions
{
    public class ExceptionMessages
    {
        public const string InvalidTypeOfFoodForAnimal = "{0} does not eat {1}!";
    }
}
