﻿namespace WildFarm.Exceptions
{
    public class InvalidTypeOfFoodForAnimal : Exception
    {
        public InvalidTypeOfFoodForAnimal(string message) : base(message){}
    }
}
