﻿namespace Vehicles.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidFuelAmount = "{0} needs refueling";
    }
}
