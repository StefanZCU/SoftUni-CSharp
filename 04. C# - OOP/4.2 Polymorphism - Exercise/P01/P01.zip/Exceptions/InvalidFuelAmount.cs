﻿namespace Vehicles.Exceptions
{
    public class InvalidFuelAmount : Exception
    {
        public InvalidFuelAmount(string message) : base(message)
        {
        }
    }
}
