﻿namespace P03.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
