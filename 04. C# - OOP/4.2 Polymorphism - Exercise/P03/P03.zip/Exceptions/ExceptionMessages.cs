﻿namespace Raiding.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidHeroException = "Invalid hero!";
    }
}
