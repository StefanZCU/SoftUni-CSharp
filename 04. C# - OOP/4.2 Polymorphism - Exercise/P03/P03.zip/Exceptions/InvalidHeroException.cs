﻿namespace Raiding.Exceptions
{
    public class InvalidHeroException : Exception
    {
        public InvalidHeroException(string message) : base(message)
        {
        }
    }
}
