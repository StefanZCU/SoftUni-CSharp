﻿namespace P03.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
