﻿namespace CollectionHierarchy.Models.Interfaces
{
    public interface IAddRemoveCollection
    {
        string Remove();
    }
}
