﻿namespace CollectionHierarchy.Models.Interfaces
{
    public interface IMyList
    {
        int Used { get; }
    }
}
