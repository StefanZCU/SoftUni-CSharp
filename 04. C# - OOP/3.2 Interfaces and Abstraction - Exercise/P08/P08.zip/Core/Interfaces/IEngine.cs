﻿namespace P08.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
