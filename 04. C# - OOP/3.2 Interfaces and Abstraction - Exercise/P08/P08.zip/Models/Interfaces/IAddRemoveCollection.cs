﻿namespace P08.Models.Interfaces
{
    public interface IAddRemoveCollection : IAddCollection
    {
        string Remove();
    }
}
