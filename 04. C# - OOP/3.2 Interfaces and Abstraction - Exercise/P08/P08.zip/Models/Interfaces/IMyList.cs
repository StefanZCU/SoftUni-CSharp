﻿namespace P08.Models.Interfaces
{
    public interface IMyList : IAddRemoveCollection
    {
        public int Used { get; }
    }
}
