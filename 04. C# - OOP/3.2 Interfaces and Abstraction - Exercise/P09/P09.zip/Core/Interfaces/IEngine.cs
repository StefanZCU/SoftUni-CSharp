﻿namespace P09.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
