﻿namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IIdentifiable
    {
        public string Birthday { get; }
    }
}
