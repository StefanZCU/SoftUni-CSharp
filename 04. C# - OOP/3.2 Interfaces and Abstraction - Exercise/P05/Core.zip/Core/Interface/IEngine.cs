﻿namespace BirthdayCelebrations.Core.Interface
{
    public interface IEngine
    {
        void Start();
    }
}
