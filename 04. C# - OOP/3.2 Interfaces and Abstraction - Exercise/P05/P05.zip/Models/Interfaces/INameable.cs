﻿namespace P05.Models.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}
