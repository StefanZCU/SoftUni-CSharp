﻿namespace P05.Models.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
