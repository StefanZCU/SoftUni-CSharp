﻿namespace BorderControl.Core.Interface
{
    public interface IEngine
    {
        public void Start();
    }
}
