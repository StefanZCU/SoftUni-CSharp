﻿namespace BorderControl.Models.Interfaces
{
    public interface IRobotInfo
    {
        public string Name { get; }
        public string ID { get; }

    }
}
