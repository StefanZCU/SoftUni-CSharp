﻿namespace BorderControl.Models.Interfaces
{
    public interface IPersonInfo : IRobotInfo
    {
        public int Age { get; }
    }
}
