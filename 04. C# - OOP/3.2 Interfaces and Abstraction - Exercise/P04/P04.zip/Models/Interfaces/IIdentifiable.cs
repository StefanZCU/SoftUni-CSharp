﻿namespace P04.Models.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
