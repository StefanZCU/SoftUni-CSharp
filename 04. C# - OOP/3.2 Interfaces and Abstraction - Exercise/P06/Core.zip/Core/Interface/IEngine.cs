﻿namespace FoodShortage.Core.Interface
{
    public interface IEngine
    {
        void Start();
    }
}
