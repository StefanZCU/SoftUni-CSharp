﻿namespace FoodShortage.Models.Interfaces
{
    public interface IIdentifier
    {
        public string Name { get; }
    }
}
