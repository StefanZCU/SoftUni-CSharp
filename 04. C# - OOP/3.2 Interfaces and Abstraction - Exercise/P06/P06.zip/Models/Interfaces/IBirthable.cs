﻿namespace P06.Models.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
