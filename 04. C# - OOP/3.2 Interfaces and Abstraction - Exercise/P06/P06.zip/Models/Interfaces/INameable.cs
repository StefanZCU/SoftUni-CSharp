﻿namespace P06.Models.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}
