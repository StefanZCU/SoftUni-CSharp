﻿namespace P07.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
