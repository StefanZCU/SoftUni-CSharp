﻿namespace P07.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
