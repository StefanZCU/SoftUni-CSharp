﻿namespace P07.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
