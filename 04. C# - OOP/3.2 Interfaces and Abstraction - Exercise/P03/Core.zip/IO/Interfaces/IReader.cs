﻿namespace Telephony.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
