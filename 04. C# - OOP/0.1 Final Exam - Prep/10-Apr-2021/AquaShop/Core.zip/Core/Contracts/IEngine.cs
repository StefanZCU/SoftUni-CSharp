﻿namespace AquaShop.Core.Contracts
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}
