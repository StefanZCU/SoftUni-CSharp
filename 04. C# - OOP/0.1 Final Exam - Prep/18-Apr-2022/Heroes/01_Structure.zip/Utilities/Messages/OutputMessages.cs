﻿namespace Heroes.Utilities.Messages
{
    public static class OutputMessages
    {
        public const string KnightsWon = "The knights took {0} casualties but won the battle.";
        public const string BarbariansWon = "The barbarians took {0} casualties but won the battle.";
    }
}
