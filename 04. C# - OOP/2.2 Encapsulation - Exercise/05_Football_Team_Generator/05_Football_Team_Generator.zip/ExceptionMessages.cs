﻿namespace _05_Football_Team_Generator
{
    public static class ExceptionMessages
    {
        public const string InvalidName = "A name should not be emepty.";
        public const string InvalidStatRange = "{0} should be between 0 and 100.";
        public const string PlayerDoesntExist = "Player {0} is not in {1} team.";
        public const string TeamDoesntExist = "Team {0} does not exist.";


    }

}
