﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=Medicines;Trusted_Connection=True;TrustServerCertificate=True";
    }
}
