﻿namespace P02_FootballBetting.Data.Common;

public static class DbConfig
{
    public const string ConnectionString =
        @"Server=localhost\SQLEXPRESS;Database=Bet388;Trusted_Connection=True;TrustServerCertificate=True";
}