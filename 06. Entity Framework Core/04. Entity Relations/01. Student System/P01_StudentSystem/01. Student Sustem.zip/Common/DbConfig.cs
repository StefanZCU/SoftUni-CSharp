﻿namespace P01_StudentSystem.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=localhost\SQLEXPRESS;Database=StudentSystem;Trusted_Connection=True;TrustServerCertificate=True";
    }
}
