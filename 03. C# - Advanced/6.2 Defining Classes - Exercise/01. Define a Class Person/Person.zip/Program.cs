﻿namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person1 = new Person("Peter", 20);
            Person person2 = new Person("George", 18);
            Person person3 = new Person("Jose", 43);
        }
    }
}