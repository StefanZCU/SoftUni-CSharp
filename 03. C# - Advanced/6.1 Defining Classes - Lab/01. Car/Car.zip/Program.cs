﻿namespace CarManufacturer;

class StartUp
{
    static void Main()
    {

    }
}


