﻿using System.Net.WebSockets;

namespace BoxOfT
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}